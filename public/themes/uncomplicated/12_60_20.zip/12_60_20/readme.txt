The 1Kb CSS Grid by Tyler Tate is licensed under GPL and free to use.

http://www.1kbgrid.com/
http://www.tylertate.com/
http://www.gnu.org/licenses/gpl.html